"""CrimeNet model-training package."""
