from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Mapping, Sequence

import numpy as np
import pandas as pd
import polars as pl


@dataclass(frozen=True)
class LoadedSplit:
    name: str
    frame: pl.DataFrame
    feature_names: tuple[str, ...]
    label_column: str
    weight_column: str | None
    metadata_columns: tuple[str, ...]

    @property
    def row_count(self) -> int:
        return self.frame.height

    @property
    def positive_count(self) -> int:
        return int(self.frame.get_column(self.label_column).cast(pl.Int64).sum())

    @property
    def positive_rate(self) -> float:
        return float(self.frame.get_column(self.label_column).cast(pl.Float64).mean())


@dataclass(frozen=True)
class ModelMatrix:
    X: pd.DataFrame
    y: np.ndarray
    sample_weight: np.ndarray | None
    metadata: pl.DataFrame


def _parse_datetime(value: str, field_name: str) -> datetime:
    try:
        return datetime.fromisoformat(value)
    except ValueError as error:
        raise ValueError(
            f"{field_name} must be an ISO-8601 datetime, received {value!r}"
        ) from error


def _resolve_dataset_glob(
    project_root: Path,
    dataset_dir: str,
    parquet_glob: str,
) -> tuple[Path, str]:
    directory = Path(dataset_dir).expanduser()
    if not directory.is_absolute():
        directory = project_root / directory
    directory = directory.resolve()

    if not directory.is_dir():
        raise FileNotFoundError(f"Dataset directory does not exist: {directory}")

    if next(directory.rglob("*.parquet"), None) is None:
        raise FileNotFoundError(f"No Parquet files were found under: {directory}")

    return directory, str(directory / parquet_glob)


def _apply_temporal_split(
    query: pl.LazyFrame,
    split_name: str,
    split_config: Mapping[str, Any],
) -> pl.LazyFrame:
    timestamp_column = str(split_config["timestamp_column"])
    validation_start = _parse_datetime(
        str(split_config["validation_start"]),
        "split.validation_start",
    )
    test_start = _parse_datetime(
        str(split_config["test_start"]),
        "split.test_start",
    )

    if validation_start >= test_start:
        raise ValueError("validation_start must be earlier than test_start")

    if split_name == "train":
        return query.filter(pl.col(timestamp_column) < validation_start)

    if split_name == "validation":
        return query.filter(
            (pl.col(timestamp_column) >= validation_start)
            & (pl.col(timestamp_column) < test_start)
        )

    if split_name == "test":
        return query.filter(pl.col(timestamp_column) >= test_start)

    raise ValueError(f"Unknown split name: {split_name!r}")


def _apply_existing_split_column(
    query: pl.LazyFrame,
    split_name: str,
    split_config: Mapping[str, Any],
) -> pl.LazyFrame:
    split_column = str(split_config.get("column", "dataset_split"))
    values = split_config.get(
        "values",
        {"train": "train", "validation": "validation", "test": "test"},
    )

    if split_name not in values:
        raise ValueError(
            f"No configured value for split {split_name!r} in split.values"
        )

    return query.filter(pl.col(split_column) == values[split_name])


def _validate_required_columns(
    schema: pl.Schema,
    required_columns: Sequence[str],
) -> None:
    missing = sorted(set(required_columns) - set(schema.names()))
    if missing:
        formatted = "\n".join(f"  - {column}" for column in missing)
        raise ValueError(f"Dataset is missing required columns:\n{formatted}")


def _validate_loaded_split(
    frame: pl.DataFrame,
    split_name: str,
    label_column: str,
    weight_column: str | None,
) -> None:
    if frame.is_empty():
        raise ValueError(f"The {split_name!r} split contains zero rows")

    if frame.get_column(label_column).null_count() > 0:
        raise ValueError(
            f"Label column {label_column!r} contains nulls in {split_name!r}"
        )

    labels = set(
        frame.get_column(label_column)
        .cast(pl.Int8)
        .unique()
        .to_list()
    )
    if not labels.issubset({0, 1}):
        raise ValueError(
            f"Label column must be binary, but {split_name!r} contains {labels}"
        )

    if weight_column is not None:
        weight = frame.get_column(weight_column)
        invalid_weight_count = frame.select(
            (
                pl.col(weight_column).is_null()
                | ~pl.col(weight_column).is_finite()
                | (pl.col(weight_column) < 0)
            ).sum()
        ).item()

        if invalid_weight_count:
            raise ValueError(
                f"{split_name!r} contains {invalid_weight_count:,} invalid weights"
            )

        if float(weight.sum()) <= 0:
            raise ValueError(f"{split_name!r} has no positive total sample weight")


def load_split(
    *,
    project_root: Path,
    data_config: Mapping[str, Any],
    split_config: Mapping[str, Any],
    split_name: str,
    feature_names: Sequence[str],
    limit: int | None = None,
    explain: bool = False,
) -> LoadedSplit:
    label_column = str(data_config["label_column"])
    use_sample_weight = bool(data_config.get("use_sample_weight", True))
    weight_column = (
        str(data_config["weight_column"])
        if use_sample_weight and data_config.get("weight_column")
        else None
    )
    metadata_columns = tuple(data_config.get("metadata_columns", ()))

    _, data_glob = _resolve_dataset_glob(
        project_root=project_root,
        dataset_dir=str(data_config["dataset_dir"]),
        parquet_glob=str(data_config.get("parquet_glob", "**/*.parquet")),
    )

    query = pl.scan_parquet(
        data_glob,
        glob=True,
        hive_partitioning=True,
        missing_columns="raise",
        extra_columns="ignore",
        use_statistics=True,
    )

    schema = query.collect_schema()

    split_mode = str(split_config.get("mode", "temporal"))
    split_filter_columns: list[str] = []

    if split_mode == "temporal":
        split_filter_columns.append(str(split_config["timestamp_column"]))
    elif split_mode == "existing_column":
        split_filter_columns.append(str(split_config.get("column", "dataset_split")))
    else:
        raise ValueError(
            "split.mode must be either 'temporal' or 'existing_column'"
        )

    required_columns = list(
        dict.fromkeys(
            [
                *feature_names,
                label_column,
                *([weight_column] if weight_column else []),
                *metadata_columns,
                *split_filter_columns,
            ]
        )
    )
    _validate_required_columns(schema, required_columns)

    if split_mode == "temporal":
        query = _apply_temporal_split(query, split_name, split_config)
    else:
        query = _apply_existing_split_column(query, split_name, split_config)

    output_columns = list(
        dict.fromkeys(
            [
                *feature_names,
                label_column,
                *([weight_column] if weight_column else []),
                *metadata_columns,
            ]
        )
    )
    query = query.select(output_columns)

    if limit is not None:
        if limit <= 0:
            raise ValueError("limit must be greater than zero")
        query = query.head(limit)

    if explain:
        print(f"\nOptimized Polars plan for {split_name}:")
        print(query.explain(optimized=True))

    frame = query.collect()
    _validate_loaded_split(frame, split_name, label_column, weight_column)

    return LoadedSplit(
        name=split_name,
        frame=frame,
        feature_names=tuple(feature_names),
        label_column=label_column,
        weight_column=weight_column,
        metadata_columns=metadata_columns,
    )


def build_category_vocabularies(
    training_split: LoadedSplit,
    categorical_columns: Sequence[str],
) -> dict[str, list[Any]]:
    vocabularies: dict[str, list[Any]] = {}

    for column in categorical_columns:
        if column not in training_split.feature_names:
            continue

        categories = (
            training_split.frame
            .get_column(column)
            .drop_nulls()
            .unique()
            .sort()
            .to_list()
        )

        if not categories:
            raise ValueError(
                f"Categorical feature {column!r} has no non-null training values"
            )

        vocabularies[column] = categories

    return vocabularies


def to_model_matrix(
    loaded_split: LoadedSplit,
    category_vocabularies: Mapping[str, Sequence[Any]],
) -> ModelMatrix:
    X = loaded_split.frame.select(loaded_split.feature_names).to_pandas()

    for column, categories in category_vocabularies.items():
        if column in X.columns:
            dtype = pd.CategoricalDtype(categories=list(categories))
            X[column] = X[column].astype(dtype)

    y = (
        loaded_split.frame
        .get_column(loaded_split.label_column)
        .cast(pl.Int8)
        .to_numpy()
    )

    sample_weight: np.ndarray | None = None
    if loaded_split.weight_column is not None:
        sample_weight = (
            loaded_split.frame
            .get_column(loaded_split.weight_column)
            .cast(pl.Float64)
            .to_numpy()
        )

    available_metadata = [
        column
        for column in loaded_split.metadata_columns
        if column in loaded_split.frame.columns
    ]
    metadata = loaded_split.frame.select(available_metadata)

    return ModelMatrix(
        X=X,
        y=y,
        sample_weight=sample_weight,
        metadata=metadata,
    )


def normalize_sample_weights(
    train: ModelMatrix,
    validation: ModelMatrix,
    test: ModelMatrix,
) -> tuple[ModelMatrix, ModelMatrix, ModelMatrix, float]:
    if train.sample_weight is None:
        return train, validation, test, 1.0

    positive_training_weights = train.sample_weight[train.sample_weight > 0]
    if positive_training_weights.size == 0:
        raise ValueError("Training split has no positive sample weights")

    divisor = float(positive_training_weights.mean())
    if not np.isfinite(divisor) or divisor <= 0:
        raise ValueError(f"Invalid sample-weight normalization divisor: {divisor}")

    def normalized(matrix: ModelMatrix) -> ModelMatrix:
        weight = (
            None
            if matrix.sample_weight is None
            else matrix.sample_weight / divisor
        )
        return ModelMatrix(
            X=matrix.X,
            y=matrix.y,
            sample_weight=weight,
            metadata=matrix.metadata,
        )

    return normalized(train), normalized(validation), normalized(test), divisor
