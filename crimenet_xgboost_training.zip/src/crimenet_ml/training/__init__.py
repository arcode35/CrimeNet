"""XGBoost training entry points."""
